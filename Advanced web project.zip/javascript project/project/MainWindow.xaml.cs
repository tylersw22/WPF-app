﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace project
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
         
        }

        private void Nutrition_MouseEnter(object sender, MouseEventArgs e)
        {
            nutrition.Opacity =0.5;
        }

        private void Nutrition_MouseLeave(object sender, MouseEventArgs e)
        {
            nutrition.Opacity = 1;
        }

        private void Nutrition_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            main.Content = new NutritionPage();
        }

        private void Training_MouseEnter(object sender, MouseEventArgs e)
        {
            training.Opacity = 0.5;
        }

        private void Training_MouseLeave(object sender, MouseEventArgs e)
        {
            training.Opacity = 1;
        }

        private void Training_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            main.Content = new TrainingPage();
        }

      
    }

}

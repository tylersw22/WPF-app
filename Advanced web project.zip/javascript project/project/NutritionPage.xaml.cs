﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;



namespace project
{
    /// <summary>
    /// Interaction logic for NutritionPage.xaml
    /// </summary>
    public partial class NutritionPage : Page
    {
        public NutritionPage()
        {
            InitializeComponent();
        }
        
        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            mealplan2.Visibility = Visibility.Hidden;
            mealplan1.Visibility = Visibility.Visible;
        }

        private void Image_MouseEnter(object sender, MouseEventArgs e)
        {
            home.Opacity = 0.5;
        }

        private void Image_MouseLeave(object sender, MouseEventArgs e)
        {
            home.Opacity = 1;
        }

        private void Home_MouseLeftButtonDown_1(object sender, MouseButtonEventArgs e)
        {
            Process.Start(Application.ResourceAssembly.Location);

            Application.Current.Shutdown();
        }

        private void Mp1_Selected(object sender, RoutedEventArgs e)
        {
            mealplan2.Visibility = Visibility.Hidden;
            mealplan1.Visibility = Visibility.Visible;
        }

        private void Mp2_Selected(object sender, RoutedEventArgs e)
        {
            mealplan1.Visibility = Visibility.Hidden;
            mealplan2.Visibility = Visibility.Visible;
        }
    }
    
}

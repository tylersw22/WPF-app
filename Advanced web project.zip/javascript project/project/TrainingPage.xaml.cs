﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;

namespace project
{
    /// <summary>
    /// Interaction logic for TrainingPage.xaml
    /// </summary>
    public partial class TrainingPage : Page
    {
        public TrainingPage()
        {
            InitializeComponent();
        }


        private void Image_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Process.Start(Application.ResourceAssembly.Location);

            Application.Current.Shutdown();
        }

        private void Image_MouseEnter(object sender, MouseEventArgs e)
        {
            home.Opacity = 0.5;
        }

        private void Home_MouseLeave(object sender, MouseEventArgs e)
        {
            home.Opacity = 1;
        }

        private void D1_Selected(object sender, RoutedEventArgs e)
        {
            day1.Visibility = Visibility.Visible;
            day2.Visibility = Visibility.Hidden;
            day3.Visibility = Visibility.Hidden;
            day4.Visibility = Visibility.Hidden;
        }

        private void D2_Selected(object sender, RoutedEventArgs e)
        {
            day1.Visibility = Visibility.Hidden;
            day2.Visibility = Visibility.Visible;
            day3.Visibility = Visibility.Hidden;
            day4.Visibility = Visibility.Hidden;
        }

        private void D3_Selected(object sender, RoutedEventArgs e)
        {
            day1.Visibility = Visibility.Hidden;
            day2.Visibility = Visibility.Hidden;
            day3.Visibility = Visibility.Visible;
            day4.Visibility = Visibility.Hidden;
        }

        private void D4_Selected(object sender, RoutedEventArgs e)
        {
            day1.Visibility = Visibility.Hidden;
            day2.Visibility = Visibility.Hidden;
            day3.Visibility = Visibility.Hidden;
            day4.Visibility = Visibility.Visible;
        }
    }
}
